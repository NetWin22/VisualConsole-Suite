#!/bin/bash

if ! command -v yad &>/dev/null; then
    echo "Error: yad not installed."
    exit 1
fi

SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
INSTALL_DIR="/usr/local/bin"
SELF_NAME="$(basename "$0")"

yad --question \
    --title="VisualConsole Suite Installer" \
    --width=400 \
    --text="Install VisualConsole Suite to /usr/local/bin?" \
    --button="Install":0 \
    --button="Cancel":1 || exit 0

if [ "$EUID" -ne 0 ]; then
    sudo -v || exit 1
fi

mapfile -t FILES < <(find "$SCRIPT_DIR" -maxdepth 1 -type f -name "*.sh" ! -name "$SELF_NAME")

TOTAL=${#FILES[@]}
[ "$TOTAL" -eq 0 ] && {
    yad --error --text="No installable scripts found."
    exit 1
}

(
count=0
for file in "${FILES[@]}"; do
    cmd_name="$(basename "$file" .sh)"
    sudo cp "$file" "$INSTALL_DIR/$cmd_name" && sudo chmod +x "$INSTALL_DIR/$cmd_name"
    ((count++))
    echo $((count * 100 / TOTAL))
    echo "# Installing $cmd_name..."
    sleep 0.15
done
) | yad --progress \
        --title="Installing VisualConsole Suite..." \
        --width=400 \
        --auto-close \
        --percentage=0 \
        --button="Cancel":1

yad --info \
    --title="Installation Complete" \
    --text="VisualConsole Suite installed successfully.\n\nOpen a new terminal to start using the commands."
