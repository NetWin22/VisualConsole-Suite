#!/bin/bash

# Richiesta password all'inizio (grafica se possibile)
if [ "$EUID" -ne 0 ]; then
    if command -v yad &>/dev/null && [ -n "$DISPLAY" ]; then
        PASSWORD=$(yad --title="Autenticazione richiesta" \
            --width=400 --center --borders=20 \
            --text="L'installer necessita dei privilegi di root.\nInserisci la tua password:" \
            --form --field="Password":H \
            --button="OK":0 --button="Annulla":1 \
            --separator="" 2>/dev/null)
        [ $? -ne 0 ] && exit 1
        echo "$PASSWORD" | sudo -S -v 2>/dev/null || { echo "Autenticazione fallita"; exit 1; }
    else
        sudo -v || exit 1
    fi
    exec sudo -E "$0" "$@"
fi

# Da qui in poi siamo root

# Verifica YAD
if ! command -v yad &>/dev/null; then
    echo "Errore: yad non è installato."
    exit 1
fi

SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"

declare -A files
files=(
    ["vcd"]="vcd.sh|Change directory"
    ["vhelp"]="vhelp.sh|Show help"
    ["vls"]="vls.sh|List directory"
    ["vrm"]="vrm.sh|Remove file"
    ["vrmdir"]="vrmdir.sh|Remove directory"
    ["vmkdir"]="vmkdir.sh|Create directory"
)

# Verifica file mancanti
missing=()
for cmd in "${!files[@]}"; do
    IFS='|' read -r filename desc <<< "${files[$cmd]}"
    [ ! -f "$SCRIPT_DIR/$filename" ] && missing+=("$filename")
done

if [ ${#missing[@]} -gt 0 ]; then
    yad --error --title="Missing Files" \
        --text="The following files are missing:\n$(printf '%s\n' "${missing[@]}")"
    exit 1
fi

# Finestra di conferma
yad --title="VisualConsole Suite Installer" \
    --width=550 --height=350 \
    --text="This installer will copy the following commands to /usr/local/bin:\n\n$(for cmd in "${!files[@]}"; do IFS='|' read -r filename desc <<< "${files[$cmd]}"; echo " • $cmd – $desc"; done)\n\nDo you want to proceed?" \
    --button="Yes, install":0 --button="No, exit":1 || exit 0

# Prepara la progress bar
TMP_FIFO=$(mktemp -u)
mkfifo "$TMP_FIFO"

yad --progress --title="Installing..." \
    --text="Starting..." \
    --width=400 --auto-close --pulsate \
    --button="Cancel":1 < "$TMP_FIFO" &
YAD_PID=$!

exec 3>"$TMP_FIFO"
echo "# Preparing..." >&3

# Funzione di copia con feedback
install_file() {
    local cmd=$1
    local src=$2
    local dest="/usr/local/bin/$cmd"
    echo "# Copying $cmd..." >&3
    sleep 0.2
    cp "$src" "$dest" && chmod +x "$dest"
}

# Esegue le copie, fermandosi al primo errore
error=0
for cmd in "${!files[@]}"; do
    IFS='|' read -r filename desc <<< "${files[$cmd]}"
    install_file "$cmd" "$SCRIPT_DIR/$filename" || { error=1; break; }
done

# Chiude la pipe e aspetta che YAD finisca
exec 3>&-
wait $YAD_PID
rm -f "$TMP_FIFO"

# Messaggio finale
if [ $error -eq 0 ]; then
    yad --info --title="Installation completed" \
        --text="VisualConsole Suite has been successfully installed.\n\nYou can now use the commands:\n$(for cmd in "${!files[@]}"; do echo -n " $cmd"; done)\n\nOpen a new terminal and try, for example: vmkdir"
else
    yad --error --title="Installation failed" \
        --text="An error occurred during the installation.\nPlease check that you have write permissions in /usr/local/bin."
    exit 1
fi
