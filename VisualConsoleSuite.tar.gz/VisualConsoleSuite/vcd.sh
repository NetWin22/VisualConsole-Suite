#!/bin/bash
(return 0 2>/dev/null)
if [ $? -ne 0 ]; then
    YELLOW='\033[1;33m'
    NC='\033[0m' # No Color
    echo -e "${YELLOW}ERROR: This script must be sourced. Use: 'source vcd'${NC}" >&2
    exit 1
fi

DIR=$(yad --form \
    --width=400 \
    --title="VisualConsole - VCD" \
    --text="Choose a directory" \
    --field="Directory":DIR \
    --button="OK":0 \
    --button="Cancel":1)

ret=$?
DIR="${DIR%%|*}"

if [ $ret -eq 0 ]; then
    if [ -d "$DIR" ]; then
        cd "$DIR" || {
            echo "Error: Could not enter directory '$DIR'" >&2
            return 1
        }
        echo "Directory changed to: $DIR"
    else
        echo "Error: Directory '$DIR' does not exist" >&2
        return 1
    fi
else
    echo "Operation cancelled." >&2
    return 0
fi
