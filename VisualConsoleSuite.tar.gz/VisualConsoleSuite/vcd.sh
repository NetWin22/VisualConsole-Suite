#!/bin/bash
DIR=$(yad --form \
    --width=400 \
    --title="VisualConsole - VCD" \
    --text="Choose a DIR path." \
    --field="Choose the directory":DIR \
    --button="OK":0 \
    --button="Cancel":1)

DIR="${DIR%%|*}"

if [ $? -eq 0 ]; then
    if [ -d "$DIR" ]; then
        cd "$DIR" || { echo "Couldn't get into the directory. Please check the path."; return 1; }
        echo "Directory changed to: $DIR"
    else
        echo "Directory does not exist: $DIR"
        exit 1
    fi
else
    echo "Operation manually closed."
    exit 0
fi
