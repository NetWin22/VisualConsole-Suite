#!/bin/bash
IFS="|" read -r PERM RECURSIVE FILES < <(yad --form \
    --title="VisualConsole - Chmod" \
    --text="Set permissions" \
    --field="Permissions (e.g., 755, u+x)":TEXT \
    --field="Recursive":CHK \
    --field="Files/Directories":MFL \
    --button="Apply":0 \
    --button="Cancel":1)

if [ $? -ne 0 ]; then
    echo "Operation cancelled."
    exit 0
fi

FILES="${FILES%%|*}"

if [ -z "$PERM" ] || [ -z "$FILES" ]; then
    echo "Permission and files are required."
    exit 1
fi

OPTIONS=""
[ "$RECURSIVE" = "TRUE" ] && OPTIONS="-R"

IFS='|' read -ra FILE_ARRAY <<< "$FILES"
for FILE in "${FILE_ARRAY[@]}"; do
    if [ -e "$FILE" ]; then
        if chmod $OPTIONS "$PERM" "$FILE" 2>/dev/null; then
            echo "Changed permissions of $FILE to $PERM"
        else
            echo "Failed to change permissions of $FILE"
        fi
    else
        echo "File not found: $FILE"
    fi
done
