#!/bin/bash
SOURCE=$(yad --file \
    --title="VisualConsole - VCP - Select source" \
    --text="Select file(s) or directory to copy" \
    --multiple \
    --separator="|" \
    --width=600 \
    --height=400)

if [ $? -ne 0 ] || [ -z "$SOURCE" ]; then
    echo "Operation manually closed."
    exit 0
fi

DEST=$(yad --file \
    --directory \
    --title="VisualConsole - VCP - Select destination" \
    --text="Select destination directory" \
    --width=600 \
    --height=400)

if [ $? -ne 0 ] || [ -z "$DEST" ]; then
    echo "Operation manually closed."
    exit 0
fi

if [[ "$SOURCE" == *"|"* ]]; then
    IFS='|' read -ra SOURCES <<< "$SOURCE"

    for ITEM in "${SOURCES[@]}"; do
        if [ -e "$ITEM" ]; then
            if cp -r "$ITEM" "$DEST/" 2>/dev/null; then
                echo "Copied: $ITEM"
            else
                echo "Failed to copy: $ITEM"
            fi
        fi
    done
    echo "Multiple items copied to $DEST"
else
    if cp -r "$SOURCE" "$DEST/"; then
        echo "Successfully copied '$SOURCE' to '$DEST/'"
    else
        echo "Failed to copy"
        exit 1
    fi
fi
