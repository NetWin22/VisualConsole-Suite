#!/bin/bash

yad --html \
    --title="VisualConsole Suite - Help" \
    --width=1000 \
    --height=650 \
    --center \
    --button="OK":0 <<EOF
<html>
<head>
<style>
body {
    background-color: #0d1117;
    color: #e6edf3;
    font-family: "JetBrains Mono", monospace;
    font-size: 11pt;
    margin: 20px;
}

h1 {
    color: #58a6ff;
    margin-bottom: 5px;
}

.subtitle {
    color: #8b949e;
    margin-bottom: 20px;
}

hr {
    border: 1px solid #30363d;
    margin: 20px 0;
}

.section-title {
    color: #79c0ff;
    margin-bottom: 15px;
}

.command-card {
    background-color: #161b22;
    border: 1px solid #30363d;
    padding: 12px;
    margin-bottom: 12px;
    border-radius: 0px;
}

.cmd {
    color: #3fb950;
    font-weight: bold;
}

.alias {
    color: #f2cc60;
}

.note {
    color: #8b949e;
    margin-top: 4px;
}

.important {
    color: #ff7b72;
    font-weight: bold;
}

.footer {
    text-align: center;
    color: #6e7681;
    margin-top: 25px;
}
</style>
</head>

<body>

<div style="text-align:center;">
    <h1>VisualConsole Suite</h1>
</div>

<hr>

<h2 class="section-title">Command Reference</h2>

<div class="command-card">
    <span class="cmd">cd</span> → <span class="alias">vuninstall</span>
    <div class="note">
        <span class="important">IMPORTANT:</span> This DELETE all the files related to the suit!</b> use only for update or to remove the suit.<br>
    </div>
</div>



<div class="command-card">
    <span class="cmd">suite help</span> → <span class="alias">vhelp</span>
    <div class="note">Opens this help window.</div>
</div>

<div class="command-card">
    <span class="cmd">cd</span> → <span class="alias">source vcd</span>
    <div class="note">
        <span class="important">IMPORTANT:</span> You must use <b>source</b> before running vcd.<br>
        Opens a directory selector and changes into it.
    </div>
</div>

<div class="command-card">
    <span class="cmd">ls</span> → <span class="alias">vls</span>
    <div class="note">Displays files and folders in the current directory.</div>
</div>

<div class="command-card">
    <span class="cmd">rm</span> → <span class="alias">vrm</span>
    <div class="note">Select and remove a file.</div>
</div>

<div class="command-card">
    <span class="cmd">rmdir</span> → <span class="alias">vrmdir</span>
    <div class="note">Select and remove a directory. Recursive deletion is supported with confirmation.</div>
</div>

<div class="command-card">
    <span class="cmd">mkdir</span> → <span class="alias">vmkdir</span>
    <div class="note">Create a new folder through a graphical interface.</div>
</div>

<div class="command-card">
    <span class="cmd">cp</span> → <span class="alias">vcp</span>
    <div class="note">Copy files or folders into a new directory.</div>
</div>

<div class="command-card">
    <span class="cmd">mv</span> → <span class="alias">vmv</span>
    <div class="note">Move files or folders into a new directory.</div>
</div>

<div class="command-card">
    <span class="cmd">touch</span> → <span class="alias">vtouch</span>
    <div class="note">Create a new file.</div>
</div>

<div class="command-card">
    <span class="cmd">chmod</span> → <span class="alias">vchmod</span>
    <div class="note">
        Change file or folder permissions.<br>
        Supports formats such as +x, 755, etc.<br>
        Optional recursive mode available.
    </div>
</div>

<hr>

<div class="footer">
    VisualConsole Suite — v1.0.0-beta.1
</div>

</body>
</html>
EOF
