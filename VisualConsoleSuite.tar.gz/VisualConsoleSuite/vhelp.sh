#!/bin/bash

yad --text-info \
    --title="VisualConsole Suite - Help" \
    --width=1000 \
    --height=350 \
    --center \
    --fontname="Monospace 11" \
    --wrap \
    --button="OK":0 <<EOF
VisualConsole Suite - Command Reference

Commands:

1. suite help = vhelp
   - Opens this help window.

2. cd = vcd
   - Opens a GUI to choose a directory and change into it.

3. ls = vls
   - Opens a GUI with the list of files and folders inside the DIR you are actually in.

4. rm = vrm
   - Opens a GUI to select a file and remove it.

5. rmdir = vrmdir
   - Opens a GUI to select a directory to remove.
   - NOTE: Even for recursive deletion (like rmdir -r), vrmdir will ask you if you want to remove
           recursively.

6. mkdir = vmkdir
   - Opens a GUI to make a folder.

Tips:
- Use GUI commands for convenience.
- All operations provide confirmations and error messages if something goes wrong.
EOF
