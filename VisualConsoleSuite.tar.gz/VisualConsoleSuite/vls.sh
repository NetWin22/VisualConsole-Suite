#!/bin/bash
yad --list --title="VisualConsole - VLS" --width=400 --height=400 --column="Files and Folders" $(ls)
