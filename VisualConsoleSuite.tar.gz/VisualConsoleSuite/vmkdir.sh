#!/bin/bash

INPUT=$(yad --form \
    --title="VisualConsole - VMKDIR" \
    --width=450 \
    --height=150 \
    --center \
    --borders=10 \
    --text="Create a new directory" \
    --field="Directory Name":TXT \
    --field="Select Path":DIR \
    --button="OK":0 \
    --button="Cancel":1 \
    --separator="|")

if [ $? -ne 0 ]; then
    exit 0
fi

IFS='|' read -r DIR_NAME PATH_DIR <<< "$INPUT"

if [ -z "$DIR_NAME" ] || [ -z "$PATH_DIR" ]; then
    yad --error --title="Errore" --text="Directory name or path missing!"
    exit 1
fi

FULL_PATH="$PATH_DIR/$DIR_NAME"

if [ -d "$FULL_PATH" ]; then
    yad --warning --title="Attenzione" --text="Directory already exists:\n$FULL_PATH"
    exit 1
fi

mkdir -p "$FULL_PATH"
if [ $? -ne 0 ]; then
    yad --error --title="Errore" --text="Failed to create directory:\n$FULL_PATH"
    exit 1
fi

yad --info --title="Successo" --text="Directory created:\n$FULL_PATH"
