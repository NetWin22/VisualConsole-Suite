#!/bin/bash
SOURCE=$(yad --file \
    --title="VisualConsole - VMV - Select source" \
    --text="Select file(s) or directory to move" \
    --multiple \
    --separator="|" \
    --width=600 \
    --height=400)

if [ $? -ne 0 ] || [ -z "$SOURCE" ]; then
    echo "Operation manually closed."
    exit 0
fi

DEST=$(yad --file \
    --directory \
    --title="VisualConsole - VMV - Select destination" \
    --text="Select destination directory" \
    --width=600 \
    --height=400)

if [ $? -ne 0 ] || [ -z "$DEST" ]; then
    echo "Operation manually closed."
    exit 0
fi

if [[ "$SOURCE" == *"|"* ]]; then
    IFS='|' read -ra SOURCES <<< "$SOURCE"

    for ITEM in "${SOURCES[@]}"; do
        if [ -e "$ITEM" ]; then
            if mv "$ITEM" "$DEST/" 2>/dev/null; then
                echo "Moved: $ITEM"
            else
                echo "Failed to move: $ITEM"
            fi
        fi
    done
    echo "Multiple items moved to $DEST"
else
    if mv "$SOURCE" "$DEST/"; then
        echo "Successfully moved '$SOURCE' to '$DEST/'"
    else
        echo "Failed to move"
        exit 1
    fi
fi
