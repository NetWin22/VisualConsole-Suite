#!/bin/bash

FILE=$(yad --form \
    --width=400 \
    --height=100 \
    --title="VisualConsole - VRM" \
    --text="Choose a FILE to remove." \
    --field="Choose the file":FL \
    --button="OK":0 \
    --button="Cancel":1)

FILE="${FILE%%|*}"

if [ $? -eq 0 ]; then
    if [ -f "$FILE" ]; then
        rm "$FILE" || { echo "Couldn't delete the file. Please check the permissions."; exit 1; }
        echo "File deleted: $FILE"
    else
        echo "File does not exist: $FILE"
        exit 1
    fi
else
    echo "Operation manually closed."
    exit 0
fi
