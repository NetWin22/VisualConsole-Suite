#!/bin/bash

delete_dir_gui() {
    DIR=$(yad --form \
        --width=400 \
        --height=100 \
        --title="VisualConsole - rmdir" \
        --text="Choose a DIRECTORY to remove." \
        --field="Choose the directory":DIR \
        --button="OK":0 \
        --button="Cancel":1)

    # Remove Yad pipe separator if present
    DIR="${DIR%%|*}"

    # Check if user pressed OK
    if [ $? -eq 0 ]; then
        if [ -d "$DIR" ]; then
            # Ask user if they want recursive deletion
            yad --question --text="Delete directory recursively?"
            if [ $? -eq 0 ]; then
                rm -r "$DIR" || { echo "Couldn't delete directory: $DIR"; exit 1; }
            else
                rmdir "$DIR" || { echo "Directory not empty or cannot delete: $DIR"; exit 1; }
            fi
            echo "Directory deleted: $DIR"
        else
            echo "Directory does not exist: $DIR"
            exit 1
        fi
    else
        echo "Operation manually closed."
        exit 0
    fi
}

# Main logic
if [ $# -gt 0 ]; then
    # If any arguments are passed, forward them directly to rmdir
    # If -r is included, use rm -r instead
    for arg in "$@"; do
        if [[ "$arg" == "-r" ]]; then
            # Use all args with rm -r
            rm -r "$@"
            exit $?
        fi
    done
    # Otherwise, just call rmdir with the arguments
    rmdir "$@"
    exit $?
else
    # No arguments → use GUI
    delete_dir_gui
fi
