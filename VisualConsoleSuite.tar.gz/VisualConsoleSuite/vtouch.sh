#!/bin/bash

INPUT=$(yad --form \
    --title="VisualConsole - VTOUCH" \
    --width=450 \
    --height=150 \
    --center \
    --borders=10 \
    --text="Create a new file" \
    --field="File Name":TXT \
    --button="OK":0 \
    --button="Cancel":1 \
    --separator="|")

if [ $? -ne 0 ]; then
    exit 0
fi

IFS='|' read -r DIR_NAME PATH_DIR <<< "$INPUT"

if [ -z "$DIR_NAME" ]; then
    yad --error --title="Error" --text="File name or path missing!"
    exit 1
fi

if [ -d "$DIR_NAME" ]; then
    yad --warning --title="Warning" --text="File already exists:\n$DIR_NAME"
    exit 1
fi

touch "$DIR_NAME"
if [ $? -ne 0 ]; then
    yad --error --title="Error" --text="Failed to create file\n$DIR_NAME"
    exit 1
fi

yad --info --title="Success" --text="File created:\n$DIR_NAME"
