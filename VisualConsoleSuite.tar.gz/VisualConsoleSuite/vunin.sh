#!/bin/bash

yad --question \
    --width=400 \
    --title="VisualConsole - Uninstall" \
    --text="Do you really want to uninstall VisualConsole Suite?" \
    --button="Yes":0 \
    --button="No":1

ret=$?

if [ $ret -eq 0 ]; then

    FILES=(
        /usr/local/bin/vhelp
        /usr/local/bin/vcd
        /usr/local/bin/vls
        /usr/local/bin/vrm
        /usr/local/bin/vrmdir
        /usr/local/bin/vmkdir
        /usr/local/bin/vcp
        /usr/local/bin/vmv
        /usr/local/bin/vtouch
        /usr/local/bin/vchmod
        /usr/local/bin/vreadme
        /usr/local/bin/vunin
    )

    # Remove only existing files
    for file in "${FILES[@]}"; do
        if [ -f "$file" ]; then
            sudo rm -f "$file"
        fi
    done

    yad --info \
        --width=350 \
        --title="Uninstall Complete" \
        --text="VisualConsole Suite has been successfully removed."

else
    yad --info \
        --width=300 \
        --title="Cancelled" \
        --text="Uninstall operation cancelled."
fi
